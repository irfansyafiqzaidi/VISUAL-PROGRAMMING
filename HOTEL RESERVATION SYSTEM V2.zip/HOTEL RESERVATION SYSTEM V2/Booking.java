//import java.text.DecimalFormat;

public class Booking
{
    // attributes
    //private double singlePrice = 85.50 , kingPrice = 125.75;
    private int roomNum , nightsStayed;
    private  String guestIC , guestContactNum , roomType , reservationStatus;
    
    //DecimalFormat df = new DecimalFormat("0.00");
    
    // normal constructor
    public Booking(String guestIC , String guestContactNum , String roomType , int roomNum , int nightsStayed , String reservationStatus)
    {
        this.guestIC = guestIC;
        this.guestContactNum = guestContactNum;
        this.roomType = roomType;
        this.roomNum = roomNum;
        this.nightsStayed = nightsStayed;
        this.reservationStatus = reservationStatus;
    }
    
    // setter
    public void setBooking(String guestIC , String guestContactNum , String roomType , int roomNum , int nightsStayed , String reservationStatus)
    {
        this.guestIC = guestIC;
        this.guestContactNum = guestContactNum;
        this.roomType = roomType;
        this.roomNum = roomNum;
        this.nightsStayed = nightsStayed;
        this.reservationStatus = reservationStatus;
    }
    
    public void setRoomType(String roomType)
    {
        this.roomType = roomType;
    }
    
    public void setNightsStayed(int nightsStayed)
    {
        this.nightsStayed = nightsStayed;
    }
    
    public void setReservationStatus(String reservationStatus)
    {
        this.reservationStatus = reservationStatus;
    }
    
    // getter
    public String getGuestIC()
    {   return guestIC;}
    
    public String getGuestContactNum()
    {   return guestContactNum;}
    
    public String getRoomType()
    {   return roomType;}
    
    public int getRoomNum()
    {   return roomNum;}
    
    public int getNightsStayed()
    {   return nightsStayed;}
    
    public String getReservationStatus()
    {   return reservationStatus;}

    public String reportPerCust()
    {
        return (String.format("|%-13s|%-18s|%-10s|%-9s|%-14s|%-19s|", guestIC , guestContactNum , roomType , roomNum , nightsStayed , reservationStatus));
    }
}