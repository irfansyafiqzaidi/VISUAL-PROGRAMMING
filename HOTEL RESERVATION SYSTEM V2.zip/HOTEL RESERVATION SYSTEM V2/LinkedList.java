import javax.swing.*;

public class LinkedList
{
    private Node first;
    private Node current;
    private Node last;
    
    public LinkedList()
    {
        first = null;
        last = null;
        current = null;
    }
    
    //check linkedList is empty or not
    public boolean isEmpty()
    {
        return (first == null);
    }
    
    //insert something from the front of linkedList
    public void insertAtFront(Object insertItem)
    {
        Node newNode = new Node(insertItem);
        
        if (isEmpty())
        {
            first = newNode;
            last = newNode;
        }
        else
        {
            newNode.next = first;
            first = newNode;
        }
    }
    
    //insert something from the back of linkedList
    public void insertAtBack(Object insertItem)
    {
        Node newNode = new Node(insertItem);
        
        if(isEmpty())
        {
            first = newNode;
            last = newNode;
        }
        else
        {
            last.next = newNode;
            last = newNode;
        }
    }
    
    //remove something from the front of linkedList
    public Object removeFromFront()
    {
        Object removeItem = null;
        if (isEmpty())
        {
            return removeItem;
        }
        
        removeItem = first.data;
        if (first == last)
        {
            first = null;
            last = null;
        }
        else
        {
            first = first.next;
        }
        
        return removeItem;
    }
    
    //remove something from the back of linkedList
    public Object removeFromBack()
    {
        Object removeItem = null;
        
        if (isEmpty())
        {
            return removeItem;
        }
        
        removeItem = last.data;
        
        if (first == last)
        {
            first = null;
            last = null;
        }
        else
        {
            current = first;
            while (current.next != last)
            {
                current = current.next;   
            }
            last = current;
            last.next = null;
        }
        
        return removeItem;
    }
    
    //retrive the first thing in the linkedList
    public Object getFirst()
    {
        if (isEmpty())
        {
            return null;
        }
        else
        {
            current = first;
            return current.data;
        }
    }
    
    //retrive the next thing in the linkedList
    public Object getNext()
    {
        if (current == last)
        {
            return null;
        }
        else
        {
            current = current.next;
            return current.data;
        }
    }
    
    //determine the linkedList size
    public int length()
    {
        int length = 0;
        current = first;
        
        while(current != null)
        {
            length++;
            current = current.next;
        }
    
        return length;
    }
    
    //remove the node specified by user (roomNumber)
    public void remove(int roomNumber)
    {
        current = first;
        Node previous = null;

        while (current != null)
        {
            if (current.data instanceof Booking)
            {
                Booking booking = (Booking) current.data;
                if (booking.getRoomNum() == roomNumber)
                {
                    if (previous == null)
                    {
                        // If the node to be removed is the first node
                        first = current.next;
                    }
                    else
                    {
                        // If the node to be removed is not the first node
                        previous.next = current.next;
                        if (current.next == null)
                        {
                            // If the node to be removed is the last node
                            last = previous;
                        }
                    }
                    System.out.println("Booking with room number " + roomNumber + " removed."); //noting that the roomNumber choosen was removed
                    return; // Exit the method after removing
                }
            }
            previous = current;
            current = current.next;
        }
        // If the room number is not found
        System.out.println("Room number " + roomNumber + " not found.");
    }
    
    //update the objects data 
    public void update(int roomNumber)
    {
        current = first;
        
        String roomType , reservationStatus;
        int nightsStayed;

        while (current != null)
        {
            if (current.data instanceof Booking)
            {
                Booking booking = (Booking) current.data;
                if (booking.getRoomNum() == roomNumber)
                {
                    // Update the attributes
                    
                    //updates the room type
                    while(true)
                    {
                        roomType = (JOptionPane.showInputDialog("Enter room type (SINGLE/KING):"));
                        
                        if("SINGLE".equalsIgnoreCase(roomType) || "KING".equalsIgnoreCase(roomType))
                        {
                            booking.setRoomType(roomType);
                            break;
                        }
                        else
                        {
                            JOptionPane.showMessageDialog(null,"INVALID INPUT!");
                        }
                    }
                    
                    //updates the nights stayed
                    while(true)
                    {
                        try
                        {
                            nightsStayed = (Integer.parseInt(JOptionPane.showInputDialog("Enter nights stayed:")));
                        
                            if(nightsStayed >0)
                            {
                                booking.setNightsStayed(nightsStayed);
                                break;
                            }
                            else
                            {
                                JOptionPane.showMessageDialog(null,"INVALID INPUT!");
                            }
                        }
                        catch(NumberFormatException e) //catch user input error, input not an int
                        {
                            JOptionPane.showMessageDialog(null,"INVALID INPUT!");
                        }
                    }
                    
                    //updates the reservation status
                    while(true)
                    {
                        reservationStatus = (JOptionPane.showInputDialog("Enter reservation status (PAID/PENDING):"));
                        
                        if("PAID".equalsIgnoreCase(reservationStatus) || "PENDING".equalsIgnoreCase(reservationStatus))
                        {
                            booking.setReservationStatus(reservationStatus);
                            break;
                        }
                        else
                        {
                            JOptionPane.showMessageDialog(null,"INVALID INPUT!");
                        }
                    }
                    
                    System.out.println("Booking with room number " + roomNumber + " updated."); //noting that the object was updated
                    return; // Exit the method after updating
                }
            }
            current = current.next;
        }

        // If the room number is not found
        System.out.println("Room number " + roomNumber + " not found.");
    }
}