public class Node
{
    public Object data;
    public Node next;
    
    public Node (Object d)
    {
        data = d;
    }
}
