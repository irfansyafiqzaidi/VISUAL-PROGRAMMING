import java.util.*; //adt
import java.io.*; //input output
import javax.swing.*; //joptionpane

public class BookingApp
{
    public static void main(String args[]) throws Exception
    {
        File file = new File("C:\\Users\\skkrrrtttt\\OneDrive\\Documents\\# WORKS\\CSC 248\\FINAL PROJECT\\FILE INPUT\\CUSTOMER.txt"); //input file and file destination
        Scanner scanFile = new Scanner(file); //scan the file
        
        //ADT
        LinkedList linkedList = new LinkedList(); //linked list for booking 
        Queue queuePaid = new Queue();            //queue for paid customer
        Queue queuePending = new Queue();         //queue for pending customer
        
        //LINKEDLIST
        while(scanFile.hasNext()) //loops until hasNext is null to break out of loop
        {
            //scan file
            String indata = scanFile.nextLine();
            StringTokenizer st = new StringTokenizer(indata, ";");
            
            //temporary attribute to store in object b, to pass in arguments in Booking normal constructor
            String guestIC = st.nextToken();
            String guestContactNum = st.nextToken();
            String roomType = st.nextToken();
            int roomNum = Integer.parseInt(st.nextToken());
            int nightsStayed = Integer.parseInt(st.nextToken());
            String reservationStatus = st.nextToken();
            
            Booking b = new Booking (guestIC , guestContactNum , roomType , roomNum , nightsStayed , reservationStatus); //arguments pass in Booking normal constructor
            
            //Question i) & ii)
            //insert from front or back
            
            //determine object b reservation status, either "PAID" or "PENDING"
            if ("PAID".equalsIgnoreCase(b.getReservationStatus()))
            {
                linkedList.insertAtFront(b); //object b is inserted from the front of linked list
            }
            else if ("PENDING".equalsIgnoreCase(b.getReservationStatus()))
            {
                linkedList.insertAtBack(b); //object b is inserted from the back of linked list
            }
        }
        
        scanFile.close(); //close scanFile
        
        //attributes for conditions
        String userRespons = "YES";
        String remUpdIns = "REMOVE"; // or "UPDATE"
        int roomNum;
        
        while(userRespons.equalsIgnoreCase("YES"))
        {
            //display table BOOKING LIST
            System.out.println("|=====================================BOOKING LIST=======================================|\n");
            System.out.println(String.format("|%-13s|%-18s|%-10s|%-9s|%-14s|%-19s|","GUEST IC","GUEST CONTACT NUM","ROOM TYPE","ROOM NUM","NIGHTS STAYED","RESERVATION STATUS"));
            System.out.println("|========================================================================================|");
        
            //Question iii)
            // getFirst & getNext , count & traversal
            Booking b = (Booking) linkedList.getFirst();        
            while (b != null)
            {
                System.out.println(b.reportPerCust()); //prints a row of object b attribute
                b = (Booking) linkedList.getNext();    //gets the next node to store in object b
            }
        
            System.out.println("|========================================================================================|\n");
        
            //display linkedlist size
            System.out.println("Size of Linked List: " + linkedList.length());        
            
            // iv)
            //display if list is empty
            System.out.println("Is the the list empty : " + linkedList.isEmpty() + "\n");
            
            do
            {
                //prompt user to modify data or not for linked list
                if(!userRespons.equalsIgnoreCase("YES") && !userRespons.equalsIgnoreCase("NO"))
                {
                    userRespons = JOptionPane.showInputDialog("INVALID INPUT! \n\nWant to REMOVE/UPDATE/INSERT data for linked list? \n(YES/NO) : ");
                }
                else
                {
                    userRespons = JOptionPane.showInputDialog("Want to REMOVE/UPDATE/INSERT data for linked list? \n(YES/NO) : ");
                }
            }
            while(!userRespons.equalsIgnoreCase("YES") && !userRespons.equalsIgnoreCase("NO"));
            
            if(userRespons.equalsIgnoreCase("YES"))
            {
                do
                {
                    //prompt user to choose either remove or update data
                    if(!remUpdIns.equalsIgnoreCase("REMOVE") && !remUpdIns.equalsIgnoreCase("UPDATE") && !remUpdIns.equalsIgnoreCase("INSERT"))
                    {
                        remUpdIns = JOptionPane.showInputDialog("INVALID INPUT! \n\nEnter 'REMOVE' to delete a data \nOR \nEnter 'UPDATE' to modify a data \nOR \nEnter 'INSERT' to add a data :");
                    }
                    else
                    {
                        remUpdIns = JOptionPane.showInputDialog("Enter 'REMOVE' to delete a data \nOR \nEnter 'UPDATE' to modify a data \nOR \nEnter 'INSERT' to add a data :");
                    }
                }
                while(!remUpdIns.equalsIgnoreCase("REMOVE") && !remUpdIns.equalsIgnoreCase("UPDATE") && !remUpdIns.equalsIgnoreCase("INSERT"));
                
                //prompt user to enter room number to remove or update data
                while(true) //infite loop until it breaks out
                {
                    if(remUpdIns.equalsIgnoreCase("REMOVE") || remUpdIns.equalsIgnoreCase("UPDATE"))
                    {
                        try
                        {
                            roomNum = Integer.parseInt(JOptionPane.showInputDialog("Enter room number (1-1000) :"));
                        
                            if(roomNum >0 && roomNum <=1000) //checks for valid room number
                            {
                                //excecute user requirements, either remove or update data
                                
                                if(remUpdIns.equalsIgnoreCase("REMOVE")) //Question v) REMOVE
                                {
                                    linkedList.remove(roomNum); //removes the choosen node
                                }
                                else if(remUpdIns.equalsIgnoreCase("UPDATE")) //Question vi) UPDATE
                                {
                                    linkedList.update(roomNum); //updates data of the choosen node
                                }
                                
                                break; //break out of infinite loop
                            }
                            else
                            {
                                JOptionPane.showMessageDialog(null,"INVALID INPUT!"); //display error message because of invalid room number entered
                            }
                        }
                        catch(NumberFormatException e) //handles exception. catch user input error, input not an int
                        {
                            JOptionPane.showMessageDialog(null,"INVALID INPUT!"); //display error message because of invalid room number entered
                        }
                    }
                    else if(remUpdIns.equalsIgnoreCase("INSERT")) //user input
                    {
                        String guestIC = JOptionPane.showInputDialog("Enter guest IC number : ");
                        String guestContactNum = JOptionPane.showInputDialog("Enter guest contact number : ");
                        String roomType = "single";
                        //Int roomNum;
                        int nightsStayed;
                        String reservationStatus = "paid";
                        
                        String insFroBac = "front";
                        
                        do
                        {
                            //prompt user to enter valid room type
                            if(!roomType.equalsIgnoreCase("SINGLE") && !roomType.equalsIgnoreCase("KING"))
                            {
                                roomType = JOptionPane.showInputDialog("INVALID INPUT! \n\nEnter room type (SINGLE/KING) : ");
                            }
                            else
                            {
                                roomType = JOptionPane.showInputDialog("Enter room type (SINGLE/KING) : ");
                            }
                        }
                        while(!roomType.equalsIgnoreCase("SINGLE") && !roomType.equalsIgnoreCase("KING"));
                        
                        while(true)
                        {
                            try
                            {
                                //prompt user to enter valid room number
                                roomNum = Integer.parseInt(JOptionPane.showInputDialog("Enter room number (1-1000) :"));
                                
                                if(roomNum >0 && roomNum <=1000)
                                {
                                    break;
                                }
                                else
                                {
                                    JOptionPane.showMessageDialog(null,"INVALID INPUT!");
                                }
                            }
                            catch(NumberFormatException e)
                            {
                                JOptionPane.showMessageDialog(null,"INVALID INPUT!");
                            }
                        }
                        
                        while(true)
                        {
                            try
                            {
                                //prompt user to enter valid nights stayed
                                nightsStayed = Integer.parseInt(JOptionPane.showInputDialog("Enter nights stayed :"));
                                
                                if(roomNum >0)
                                {
                                    break;
                                }
                                else
                                {
                                    JOptionPane.showMessageDialog(null,"INVALID INPUT!");
                                }
                            }
                            catch(NumberFormatException e)
                            {
                                JOptionPane.showMessageDialog(null,"INVALID INPUT!");
                            }
                        }
                        
                        do
                        {
                            //prompt user to enter valid reservaion status
                            if(!reservationStatus.equalsIgnoreCase("PAID") && !reservationStatus.equalsIgnoreCase("PENDING"))
                            {
                                reservationStatus = JOptionPane.showInputDialog("INVALID INPUT! \n\nEnter reservation status (PAID/PENDING) : ");
                            }
                            else
                            {
                                reservationStatus = JOptionPane.showInputDialog("Enter reservation status (PAID/PENDING) : ");
                            }
                        }
                        while(!reservationStatus.equalsIgnoreCase("PAID") && !reservationStatus.equalsIgnoreCase("PENDING"));
                        
                        b = new Booking (guestIC , guestContactNum , roomType , roomNum , nightsStayed , reservationStatus);
                        
                        do
                        {
                            //prompt user to enter data either from front or back of linked list
                            if(!insFroBac.equalsIgnoreCase("FRONT") && !insFroBac.equalsIgnoreCase("BACK"))
                            {
                                insFroBac = JOptionPane.showInputDialog("INVALID INPUT! \n\nWhere to insert data (FRONT/BACK) : ");
                            }
                            else
                            {
                                insFroBac = JOptionPane.showInputDialog("Where to insert data (FRONT/BACK) : ");
                            }
                        }
                        while(!insFroBac.equalsIgnoreCase("FRONT") && !insFroBac.equalsIgnoreCase("BACK"));
                        
                        if(insFroBac.equalsIgnoreCase("FRONT"))
                        {
                            linkedList.insertAtFront(b); //object b is inserted from the front of linked list
                            System.out.println("New item INSERTED at the FRONT");
                        }
                        else if(insFroBac.equalsIgnoreCase("BACK"))
                        {
                            linkedList.insertAtBack(b); //object b is inserted from the back of linked list
                            System.out.println("New item INSERTED at the BACK");
                        }
                        
                        break;
                    }
                }
            }
        }
        
        //QUEUE
        
        //Question i) enqueue
        
        Booking tempCust = (Booking) linkedList.getFirst(); //gets the first node in linkedList to store in tempCust
        
        while(tempCust != null) //loops while tempCust is not null
        {
            //determine the object b status reservation either "PAID" or "PENDING" customer
            if("PAID".equalsIgnoreCase(tempCust.getReservationStatus()))
            {
                queuePaid.enqueue(tempCust.reportPerCust()); //enqueue the object into paid customer queue
            }
            else if("PENDING".equalsIgnoreCase(tempCust.getReservationStatus())) // tempCust.getResrvationaStatus().we
            {
                queuePending.enqueue(tempCust.reportPerCust()); //enqueue the object into pending customer queue
            }
            
            tempCust = (Booking) linkedList.getNext(); //gets the next node in linked list to assign in tempCust
        }
        
        userRespons = "YES";
        
        while(userRespons.equalsIgnoreCase("YES"))
        {
            do
            {
                //prompt user to enqueue new data
                if(!userRespons.equalsIgnoreCase("YES") && !userRespons.equalsIgnoreCase("NO"))
                {
                    userRespons = JOptionPane.showInputDialog("INVALID INPUT! \n\nWant to enqueue new data ? \n(YES/NO) : ");
                }
                else
                {
                    userRespons = JOptionPane.showInputDialog("Want to enqueue new data ? \n(YES/NO) : ");
                }
            }
            while(!userRespons.equalsIgnoreCase("YES") && !userRespons.equalsIgnoreCase("NO"));
            
            if(userRespons.equalsIgnoreCase("YES"))
            {
                String guestIC = JOptionPane.showInputDialog("Enter guest IC number : ");
                String guestContactNum = JOptionPane.showInputDialog("Enter guest contact number : ");
                String roomType = "single";
                //Int roomNum;
                int nightsStayed;
                String reservationStatus = "paid";
                
                do
                {
                    //prompt user to enter valid room type
                    if(!roomType.equalsIgnoreCase("SINGLE") && !roomType.equalsIgnoreCase("KING"))
                    {
                        roomType = JOptionPane.showInputDialog("INVALID INPUT! \n\nEnter room type (SINGLE/KING) : ");
                    }
                    else
                    {
                        roomType = JOptionPane.showInputDialog("Enter room type (SINGLE/KING) : ");
                    }
                }
                while(!roomType.equalsIgnoreCase("SINGLE") && !roomType.equalsIgnoreCase("KING"));
                
                while(true)
                {
                    try
                    {
                        //prompt user to enter valid room number
                        roomNum = Integer.parseInt(JOptionPane.showInputDialog("Enter room number (1-1000) :"));
                                
                        if(roomNum >0 && roomNum <=1000)
                        {
                            break;
                        }
                        else
                        {
                            JOptionPane.showMessageDialog(null,"INVALID INPUT!");
                        }
                    }
                    catch(NumberFormatException e)
                    {
                        JOptionPane.showMessageDialog(null,"INVALID INPUT!");
                    }
                }
                
                while(true)
                {
                    try
                    {
                        //prompt user to enter valid nights stayed
                        nightsStayed = Integer.parseInt(JOptionPane.showInputDialog("Enter nights stayed :"));
                                
                        if(roomNum >0)
                        {
                             break;
                        }
                        else
                        {
                            JOptionPane.showMessageDialog(null,"INVALID INPUT!");
                        }
                    }
                    catch(NumberFormatException e)
                    {
                        JOptionPane.showMessageDialog(null,"INVALID INPUT!");
                    }
                }
                
                do
                {
                    //prompt user to enter valid reservaion status
                    if(!reservationStatus.equalsIgnoreCase("PAID") && !reservationStatus.equalsIgnoreCase("PENDING"))
                    {
                        reservationStatus = JOptionPane.showInputDialog("INVALID INPUT! \n\nEnter reservation status (PAID/PENDING) : ");
                    }
                    else
                    {
                        reservationStatus = JOptionPane.showInputDialog("Enter reservation status (PAID/PENDING) : ");
                    }
                }
                while(!reservationStatus.equalsIgnoreCase("PAID") && !reservationStatus.equalsIgnoreCase("PENDING"));
                
                Booking b = new Booking (guestIC , guestContactNum , roomType , roomNum , nightsStayed , reservationStatus);
                
                //enqueuing new data from user input
                if("PAID".equalsIgnoreCase(b.getReservationStatus()))
                {
                    queuePaid.enqueue(b.reportPerCust());
                }
                else if("PENDING".equalsIgnoreCase(b.getReservationStatus()))
                {
                    queuePending.enqueue(b.reportPerCust());
                }
                
                System.out.println("New customer with room number " + b.getRoomNum() + " has been added in queue");
            }
        }
        
        //Question ii) dequeue , iii) display size , iv) isEmpty
        
        //Paid Customer Queue
        
        System.out.println("\nSize of Paid Customer Queue : " + queuePaid.length()); //paid customer queue size
        System.out.println("Is the queue empty : " + queuePaid.isEmpty() + "\n");  //checks if paid customer queue size empty or not
        
        System.out.println("|=====================================PAID CUSTOMER======================================|\n");
        System.out.println(String.format("|%-13s|%-18s|%-10s|%-9s|%-14s|%-19s|","GUEST IC","GUEST CONTACT NUM","ROOM TYPE","ROOM NUM","NIGHTS STAYED","RESERVATION STATUS"));
        System.out.println("|========================================================================================|");
        
        while(!queuePaid.isEmpty()) //loops while queuePaid is not empty
        {
            System.out.println(queuePaid.dequeue()); //prints out the obj info
        }
        
        System.out.println("|========================================================================================|\n");
        
        //Pending Customer Queue
        
        System.out.println("Size of Pending Customer Queue : " + queuePending.length()); //pending customer queue size
        System.out.println("Is the queue empty : " + queuePending.isEmpty() + "\n");     //checks if pending customer queue size empty or not
        
        System.out.println("|====================================PENDING CUSTOMER====================================|\n");
        System.out.println(String.format("|%-13s|%-18s|%-10s|%-9s|%-14s|%-19s|","GUEST IC","GUEST CONTACT NUM","ROOM TYPE","ROOM NUM","NIGHTS STAYED","RESERVATION STATUS"));
        System.out.println("|========================================================================================|");
        
        while(!queuePending.isEmpty()) //loops while queuePending is not empty
        {
            System.out.println(queuePending.dequeue()); //prints out the obj info
        }
        
        System.out.println("|========================================================================================|");
    }
}