public class Queue extends LinkedList
{
    public Queue()
    {}
    
    //enqueu something in the queue
    public void enqueue(Object elem)
    {
        insertAtBack(elem);
    }

    //dequeu something in the queue
    public Object dequeue()
    {
        return removeFromFront();
    }

    //gets the first thing in the queue
    public Object getFront()
    {
        return getFirst();
    }

    //gets the last thing in the queue
    public Object getEnd()
    {
        Object obj = removeFromFront();
        insertAtBack(obj); // reinsert
        return obj;
    }
}